import { registerRoute } from 'workbox-routing';
import { StaleWhileRevalidate } from 'workbox-strategies';
import { CacheStorage } from 'workbox-core';

export function registerSW() {
  if ('serviceWorker' in navigator) {
    // eslint-disable-next-line no-undef
    const swUrl = `${process.env.PUBLIC_URL}/service-worker.js`;
    navigator.serviceWorker.register(swUrl).then((registration) => {
      registration.onupdatefound = () => {
        const installingWorker = registration.installing;
        installingWorker.onstatechange = () => {
          if (installingWorker.state === 'installed') {
            if (navigator.serviceWorker.controller) {
              // New content is available, prompt to refresh
              console.log('New content is available; please refresh.');
              // Optionally show a toast
              // dispatch(showToast({ type: 'info', message: 'New version available!' }));
            } else {
              // Content is cached for offline use.
              console.log('Content cached for offline use.');
            }
          }
        };
      };
    }).catch((error) => {
      console.error('Service worker registration failed: ', error);
    });
  }
}