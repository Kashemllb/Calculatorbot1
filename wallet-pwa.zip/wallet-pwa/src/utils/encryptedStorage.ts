import { localforage, CryptoKey } from 'localforage';
import { subtle } from 'crypto-helpers'; // we will polyfill below

// We'll use localforage with a custom driver that supports crypto.
// localforage defaults to IndexedDB.

type EncryptedStorageType = 'localforage';

export interface EncryptedStorageOptions {
  key: string;
  ttl?: number; // time-to-live in seconds
}

/**
 * Encrypted storage wrapper that encrypts values using Web Crypto API
 * derived from a user PIN. The encrypted blob is stored in indexedDB/localStorage.
 */
export class EncryptedStorage {
  private key: string;
  private ttl: number | undefined;
  private derivedKey: CryptoKey | null = null;

  constructor(options: EncryptedStorageOptions) {
    this.key = options.key;
    this.ttl = options.ttl;
    this.initDerivedKey().catch(console.error);
  }

  private async initDerivedKey() {
    // In a real app, you would prompt the user for PIN and derive key via PBKDF2.
    // For this demo, we generate a static key from a master password.
    // TODO: replace with actual PIN-derived key.
    const masterPassword = 'default-secret'; // never hardcode in production
    const encoder = new TextEncoder();
    const passwordBytes = encoder.encode(masterPassword);
    // Derive a key using PBKDF2 ( Web Crypto )
    const keyMaterial = await subtle.importKey(
      'raw',
      passwordBytes,
      { name: 'PBKDF2' },
      false,
      ['deriveKey']
    );
    this.derivedKey = await subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: new TextEncoder().encode('wallet-salt'), // static salt - rotate per user
        iterations: 100000,
        hash: 'SHA-256',
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  private async getDerivedKey(): Promise<CryptoKey> {
    if (!this.derivedKey) await this.initDerivedKey();
    return this.derivedKey;
  }

  async set(value: any, options?: { ttl?: number }) {
    const key = this.key;
    const cryptoKey = await this.getDerivedKey();
    const json = JSON.stringify(value);
    const encoder = new TextEncoder();
    const data = encoder.encode(json);
    // Generate random IV
    const iv = crypto.getRandomValues(new Uint8Array(12)); // 96-bit IV for GCM
    const encrypted = await subtle.encrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      data
    );
    const result = {
      iv: Array.from(iv),
      data: Array.from(new Uint8Array(encrypted)),
    };
    const serialized = JSON.stringify(result);
    // Store in localforage (indexedDB)
    await localforage.setItem(key, serialized);
    if (options?.ttl) {
      // Could store expiry and check on get; omitted for brevity.
    }
  }

  async get<T>(defaultValue: T): Promise<T> {
    const key = this.key;
    const serialized = await localforage.getItem<string>(key);
    if (!serialized) return defaultValue;
    try {
      const result = JSON.parse(serialized);
      const cryptoKey = await this.getDerivedKey();
      const iv = new Uint8Array(result.iv as number[]);
      const data = new Uint8Array(result.data as number[]);
      const decrypted = await subtle.decrypt(
        { name: 'AES-GCM', iv },
        cryptoKey,
        data
      );
      const json = JSON.parse(new TextDecoder().decode(decrypted));
      // Check TTL if provided
      if (this.ttl && json.exp && Date.now() - json.exp > this.ttl * 1000) {
        return defaultValue;
      }
      return json as unknown as T;
    } catch (e) {
      console.error('Failed to decrypt storage', e);
      return defaultValue;
    }
  }

  async remove() {
    await localforage.removeItem(this.key);
  }
}

// Helper functions for hook usage
export async function encryptValue(value: any, key: string) {
  const storage = new EncryptedStorage({ key });
  await storage.set(value);
}

export async function decryptValue<T>(key: string, defaultValue: T): Promise<T> {
  const storage = new EncryptedStorage({ key });
  return storage.get<T>(defaultValue);
}