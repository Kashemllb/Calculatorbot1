import { configureStore } from '@reduxjs/toolkit';
import walletReducer from '../features/walletSlice';
import networkReducer from '../features/networkSlice';
import tokenReducer from '../features/tokenSlice';

export const store = configureStore({
  reducer: {
    wallet: walletReducer,
    network: networkReducer,
    token: tokenReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Ignore these action types
        ignoredActions: ['persisted/PURGE', 'persisted/REGISTER'],
      },
    }),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;