import React from 'react';
import { useConnect, useDisconnect, useAccount } from 'wagmi';
import { useRouter } from 'react-router-dom';
import { Box, Button, Text, Badge } from '@daisyui/react';
import { usePinLock } from '../hooks/usePinLock';

export const WalletConnect: React.FC = () => {
  const { connect, isConnecting } = useConnect();
  const { disconnect } = useDisconnect();
  const { address, chainId } = useAccount();
  const { isUnlocked } = usePinLock();
  const router = useRouter();

  const handleConnect = async () => {
    if (!isUnlocked) {
      alert('Please unlock your wallet first (PIN).');
      return;
    }
    try {
      await connect({ provider: { preferences: { peer: { wallets: [{ name: 'MetaMask' }] } } } });
      // After connect, wagmi fills address & chainId; redirect to home
      router.push('/');
    } catch (e) {
      console.error('Connection failed', e);
      alert('Wallet connection failed. Please try again.');
    }
  };

  const handleDisconnect = async () => {
    await disconnect();
    router.push('/');
  };

  return (
    <Box className="space-y-2">
      {address ? (
        <Badge variant="outline">
          {address.slice(0, 6)}…{address.slice(-4)}
        </Badge>
      ) : (
        <Button onClick={handleConnect} disabled={!isUnlocked} className="w-full">
          {isConnecting ? 'Connecting…' : 'Connect Wallet'}
        </Button>
      )}
      <Button onClick={handleDisconnect} variant="destructive" className="w-full mt-2">
        Disconnect
      </Button>
    </Box>
  );
};