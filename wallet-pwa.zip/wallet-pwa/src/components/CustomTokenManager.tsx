import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { addCustomToken, removeCustomToken, updateCustomToken } from '../features/tokenSlice';
import { Box, Input, Button, Card, Image } from '@daisyui/react';

export const CustomTokenManager: React.FC = () => {
  const dispatch = useDispatch();
  const [address, setAddress] = useState<string>('');
  const [meta, setMeta] = useState<{
    symbol: string;
    decimals: number;
    logo: string;
    name: string;
  } | null>(null);
  const [error, setError] = useState<string>('');

  // Simple fetch from Covalent API (requires API key; for demo we use a public endpoint placeholder)
  const fetchTokenMeta = async (addr: string) => {
    setError('');
    setMeta(null);
    try {
      // Covalent API v2 (free tier). Replace KEY with your own.
      const API_KEY = 'your-covalent-key'; // in production use env var
      const url = `https://api.covalenthq.com/v1/1/tokens/${addr}/?key=${API_KEY}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch token metadata');
      const data = await res.json();
      // Covalent returns data.data.items[0]
      const item = data.data?.items?.[0];
      if (!item) throw new Error('No token data returned');
      const symbol = item.symbol ?? '';
      const decimals = item.decimals ?? 18;
      const logo = item.logo ?? '';
      const name = item.name ?? '';
      setMeta({ symbol, decimals, logo, name });
    } catch (e: any) {
      console.error(e);
      setError(e.message || 'Unknown error fetching token metadata');
    }
  };

  const handleAdd = () => {
    const addr = address.toLowerCase();
    if (!/^0x[a-fA-F0-9]{40}$/.test(addr)) {
      setError('Invalid Ethereum address');
      return;
    }
    // If we already have meta from cache, use it; otherwise fetch
    if (meta) {
      dispatch(addCustomToken({ address: addr, ...meta }));
      setAddress('');
      setMeta(null);
      return;
    }
    fetchTokenMeta(addr);
    // Show a pending state; in real app we'd wait for fetch completion.
  };

  const handleRemove = (addr: string) => {
    dispatch(removeCustomToken(addr));
  };

  const handleUpdate = (addr: string, fields: Partial<{
    symbol: string;
    decimals: number;
    logo: string;
    name: string;
  }>) => {
    dispatch(updateCustomToken({ address: addr, fields }));
  };

  return (
    <Box className="space-y-4">
      <h2 className="text-xl font-bold">Custom Tokens</h2>

      {/* Add token form */}
      <Input
        placeholder="ERC-20 contract address"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
        disabled={!!meta}
        className="mr-2"
      />
      <Button onClick={handleAdd} disabled={!/^0x[a-fA-F0-9]{40}$/.test(address)}>
        Add Token
      </Button>
      {error && <p className="text-red-500">{error}</p>}

      {/* Display added tokens */}
      <Card className="mt-4">
        <CardHeader>
          <h3 className="text-sm">My Tokens</h3>
        </CardHeader>
        <CardContent>
          {Object.values(dispatch().getState ? dispatch().getState().token.customTokens : {} as any).map((t: any) => (
            <div key={t.address} className="flex items-center space-x-3 py-2">
              <Image src={t.logo || '/images/default-token.svg'} alt={t.symbol} width={40} height={40} className="rounded"/>
              <div className="flex-1">
                <span className="font-medium">{t.symbol}</span>
                <span className="text-xs text-gray-400">{t.name}</span>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleRemove(t.address)}
                className="flex-1 text-sm"
              >
                Remove
              </Button>
            </div>
          ))}
          {Object.keys(dispatch().getState ? dispatch().getState().token.customTokens : {}).length === 0 && <p className="text-gray-400">No custom tokens added.</p>}
        </CardContent>
      </Card>
    </Box>
  );
};