import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Card, CardHeader, CardTitle, CardContent, Spinner } from '@daisyui/react';
import { selectChain } from '../features/networkSlice'; // placeholder

export const BalanceDisplay: React.FC = () => {
  const dispatch = useDispatch();
  const { chainId, chainName } = useSelector((state: any) => state.network);
  const { address } = useSelector((state: any) => state.wallet);

  const [balances, setBalances] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!address) {
      setBalances({});
      setLoading(false);
      return;
    }
    // In a real app, use wagmi's useBalance or ethers provider to fetch.
    // Here we simulate with a setTimeout.
    const simulateFetch = async () => {
      // Mock balances for mainnet tokens
      const mock = {
        '0xC02aaA39b223FE8D0A0e5C4F27e99897897B0A5d': '1234.56', // WETH
        '0xdAC17F958D2ee523a2206206994597C13D831ec7': '5678.90', // USDC
      };
      const result: Record<string, string> = {};
      for (const [addr, symbol] of Object.entries(mock)) {
        result[addr] = `${Math.floor(Math.random() * 10000) / 100} ${symbol}`;
      }
      setBalances(result);
      setLoading(false);
    };
    simulateFetch();
  }, [address, chainId]);

  return (
    <Box className="space-y-4">
      <h2 className="text-xl font-bold">Balance</h2>
      <Card>
        <CardHeader>
          <CardTitle>{chainName || 'Network'}</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Spinner />
          ) : (
            <div className="space-y-2">
              {address ? (
                Object.entries(balances).map(([addr, bal]) => (
                  <div key={addr} className="flex items-center justify-between p-2 bg-gray-100 rounded">
                    <span className="flex-1">
                      {bal}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => dispatch(selectChain(chainId ?? '0x1'))}
                      className="text-xs"
                    >
                      Details
                    </Button>
                  </div>
                ))
                ) : (
                    <p className="text-gray-400">Connect wallet to see balances.</p>
                  )}
            </div>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};