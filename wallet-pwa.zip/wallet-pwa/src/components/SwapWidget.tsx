import React from 'react';
import { Box, Button, Input, Select, Option } from '@daisyui/react';

export const SwapWidget: React.FC = () => {
  const [fromChain, setFromChain] = useState<'eth' | 'bsc' | 'arbitrum' | 'optimism' | 'polygon'>('eth');
  const [toChain, setToChain] = useState<'eth' | 'bsc' | 'arbitrum' | 'optimism' | 'polygon'>('eth');
  const [fromAmount, setFromAmount] = useState<string>('');
  const [toAmount, setToAmount] = useState<string>('');

  const quotes = {
    ethToBsc: '500', // placeholder
    bscToEth: '450',
  };

  const handleSwap = () => {
    const from = fromChain;
    const to = toChain;
    const amount = fromAmount || '1';
    // Open 1inch widget in new tab
    const url = `https://1inch.io/token-swaps/#/1/${from}/${to}/${amount}`;
    window.open(url, '_blank');
  };

  return (
    <Box className="space-y-4 max-w-md w-full">
      <h2 className="text-xl font-bold">Swap</h2>

      <Select onValueChange={setFromChain} defaultValue="eth">
        <Option value="eth">Ethereum</Option>
        <Option value="bsc">BSC</Option>
        <Option value="arbitrum">Arbitrum</Option>
        <Option value="optimism">Optimism</Option>
        <Option value="polygon">Polygon</Option>
      </Select>

      <Select onValueChange={setToChain} defaultValue="bsc">
        <Option value="eth">Ethereum</Option>
        <Option value="bsc">BSC</Option>
        <Option value="arbitrum">Arbitrum</Option>
        <Option value="optimism">Optimism</Option>
        <Option value="polygon">Polygon</Option>
      </Select>

      <Input
        type="number"
        placeholder="From amount"
        value={fromAmount}
        onChange={(e) => setFromAmount(e.target.value)}
        min="0"
        step="any"
      />
      <Button onClick={handleSwap} width="100%" disabled={!fromAmount}>
        Swap via 1inch
      </Button>

      <p className="text-sm">
        <strong>To amount:</strong> {toAmount} (estimated)
      </p>
    </Box>
  );
};