import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { setNetwork, addCustomNetwork, removeNetwork } from '../features/networkSlice';
import { Box, Input, Button, Select, Option, Label } from '@daisyui/react';
import { useChains } from '../hooks/useChains';

export const NetworkManager: React.FC = () => {
  const dispatch = useDispatch();
  const { chains, getChainById, selectChain } = useChains();
  const [customRpc, setCustomRpc] = useState<string>('');
  const [customName, setCustomName] = useState<string>('');

  useEffect(() => {
    // Initialize current network from Redux if set
    const stored = localStorage.getItem('selectedChainId');
    if (stored) {
      dispatch(setNetwork({ chainId: stored, chainName: 'Custom', rpcUrl: '', custom: true }));
    }
  }, [dispatch]);

  const handleAddCustom = async () => {
    if (!customRpc || !customName) return;
    const chainId = Math.floor(Math.random() * 0xFFFFFFFF).toString(16); // placeholder
    dispatch(addCustomNetwork({
      chainId,
      chainName: customName,
      rpcUrl: customRpc,
      explorerUrl: `https://${customName.toLowerCase().replace(/\s+/g, '')}.explorer.example.com`,
    }));
    setCustomRpc('');
    setCustomName('');
  };

  const handleRemove = () => {
    dispatch(removeNetwork());
  };

  return (
    <Box className="space-y-4">
      <h2 className="text-xl font-bold">Networks</h2>

      {/* Current network display */}
      <div>
        <Label>Current Chain:</Label>
        <Select onValueChange={(val: string) => {
          const chain = getChainById(val as string);
          if (chain) selectChain(chain);
        }}>
          <Option value="Ethereum Mainnet">Ethereum Mainnet</Option>
          <Option value="BSC">BSC</Option>
          <Option value="Arbitrum">Arbitrum</Option>
          <Option value="Optimism">Optimism</Option>
          <Option value="Polygon">Polygon</Option>
          {/* dynamic custom */}
          {chains.map((c) => (
            <Option key={c.chainId} value={c.chainId}>
              {c.chainName}
            </Option>
          ))}
        </Select>
        {chains.some(c => c.custom) && (
          <Button onClick={handleRemove} variant="outline" size="sm">
            Remove custom network
          </Button>
        )}
      </div>

      {/* Add custom network form */}
      <Input
        placeholder="Custom RPC URL"
        value={customRpc}
        onChange={(e) => setCustomRpc(e.target.value)}
        className="mr-2"
      />
      <Input
        placeholder="Chain name"
        value={customName}
        onChange={(e) => setCustomName(e.target.value)}
        className="mr-2"
      />
      <Button onClick={handleAddCustom} disabled={!customRpc || !customName}>
        Add Custom Network
      </Button>
    </Box>
  );
};