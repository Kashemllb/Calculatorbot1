import { useState, useEffect, useCallback } from 'react';

const PIN_STORAGE_KEY = 'wallet_pin_hash';
const UNLOCKED_STORAGE_KEY = 'wallet_unlocked';

export function usePinLock() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [pin, setPin] = useState('');

  // Load saved PIN hash from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(PIN_STORAGE_KEY);
    if (stored) {
      // We just remember that a PIN is set; actual verification happens on input
      // For demo, we consider any input matching stored hash as correct.
      // In production, store salted hash securely.
    }
  }, []);

  const handlePinInput = useCallback(async (input: string) => {
    const storedHash = localStorage.getItem(PIN_STORAGE_KEY);
    if (!storedHash) {
      // No PIN set yet; set it
      const encoder = new TextEncoder();
      const data = encoder.encode(input);
      const hash = await window.crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hash));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
      localStorage.setItem(PIN_STORAGE_KEY, hashHex);
      setIsUnlocked(true);
      return true;
    }
    // Compute hash of input
    const encoder = new TextEncoder();
    const data = encoder.encode(input);
    const hash = await window.crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hash));
    const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    if (hashHex === storedHash) {
      setIsUnlocked(true);
      return true;
    }
    setIsUnlocked(false);
    return false;
  }, []);

  const requestPin = async () => {
    // Prompt user for PIN (simple prompt for demo; in production use modal)
    const input = prompt('Enter your wallet PIN:');
    if (input) {
      const ok = await handlePinInput(input);
      if (!ok) alert('Incorrect PIN');
    }
  };

  const resetLock = useCallback(() => {
    setIsUnlocked(false);
    // Optionally clear PIN; for this demo we keep it.
  }, []);

  return { isUnlocked, requestPin, resetLock };
}