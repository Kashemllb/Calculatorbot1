import { useEffect, useState } from 'react';

export function useSessionTimeout(onLock: () => void, timeoutMs: number) {
  const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleActivity = () => {
      // Reset the timer on any mousemove / keydown
      clearTimeout(timeoutId as NodeJS.Timeout);
      const newId = setTimeout(onLock, timeoutMs);
      setTimeoutId(newId);
    };

    // Initial setup
    const start = () => {
      clearTimeout(timeoutId as NodeJS.Timeout);
      setTimeoutId(setTimeout(onLock, timeoutMs));
    };

    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('keydown', handleActivity);
    window.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        // user left tab, maybe lock immediately
        clearTimeout(timeoutId as NodeJS.Timeout);
        onLock();
      } else {
        start();
      }
    });

    // Start timer
    start();

    return () => {
      clearTimeout(timeoutId as NodeJS.Timeout);
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('visibilitychange', () => {});
    };
  }, [onLock, timeoutId, timeoutMs]);

  return { timeoutId, startTimeout: useCallback(start, []), clearTimeout: useCallback(() => clearTimeout(timeoutId as NodeJS.Timeout), []) };
}