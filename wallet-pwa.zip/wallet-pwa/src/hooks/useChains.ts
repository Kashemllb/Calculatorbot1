import { useEffect, useState } from 'react';
import chains from '../utils/chains.json';

export interface Chain {
  chainId: string;
  chainName: string;
  rpcUrls: string[];
  explorerUrl: string;
  iconBackgroundColor: string;
  nativeCurrency: { name: string; symbol: string; decimals: number };
}

export function useChains() {
  const [chains, setChains] = useState<Chain[]>([]);
  const [selectedChainId, setSelectedChainId] = useState<string>('0x1');

  useEffect(() => {
    // Transform raw config into flat Chain objects
    const transformed = chains.chains.map((c: any) => ({
      chainId: c.chainId,
      chainName: c.chainName,
      rpcUrls: c.rpcUrls,
      explorerUrl: c.explorerUrl,
      iconBackgroundColor: c.iconBackgroundColor,
      nativeCurrency: c.nativeCurrency,
    }));
    setChains(transformed);
    // Select first chain by default
    if (transformed.length > 0) {
      setSelectedChainId(transformed[0].chainId);
    }
  }, []);

  const getChainById = (id: string) => chains.find((c) => c.chainId === id);

  const selectChain = (chain: Chain) => {
    // In a real app, you'd switch the provider via wagmi
    setSelectedChainId(chain.chainId);
    // Persist selection
    localStorage.setItem('selectedChainId', chain.chainId);
  };

  return { chains, getChainById, selectChain, selectedChainId };
}