import { useEffect, useState } from 'react';

export function useTheme() {
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system');

  useEffect(() => {
    const setThemeFromPref = () => {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(prefersDark ? 'dark' : 'light');
    };
    setThemeFromPref();
    const mq = window.matchMedia('(prefers-color-scheme: light | dark)');
    mq.addEventListener('change', setThemeFromPref);
    return () => mq.removeEventListener('change', setThemeFromPref);
  }, []);

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'system') {
      root.classList.remove('light', 'dark');
      root.classList.add('auto');
    } else {
      root.classList.remove('light', 'dark', 'auto');
      root.classList.add(theme);
    }
  }, [theme]);

  const toggle = () => {
    if (theme === 'system') {
      setTheme('dark');
    } else if (theme === 'dark') {
      setTheme('light');
    } else {
      setTheme('system');
    }
  };

  return { theme, toggle };
}