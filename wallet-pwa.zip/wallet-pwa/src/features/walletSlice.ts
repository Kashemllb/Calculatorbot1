import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface WalletState {
  address: string | null;
  provider: any | null;
  connected: boolean;
  chainId: string | null;
  balances: Record<string, string>; // tokenAddress -> balance
  selectedAddress: string | null;
}

const initialState: WalletState = {
  address: null,
  provider: null,
  connected: false,
  chainId: null,
  balances: {},
  selectedAddress: null,
};

export const walletSlice = createSlice({
  name: 'wallet',
  initialState,
  reducers: {
    connectWallet(state, action: PayloadAction<{ address: string; provider: any }>) {
      state.address = action.payload.address;
      state.provider = action.payload.provider;
      state.connected = true;
      // on connect, user's default chain is usually Ethereum mainnet; we set chainId from provider
      if (action.payload.provider?.getNetwork) {
        // wagmi provides provider; we'll just set placeholder
        state.chainId = '0x1'; // mainnet
      }
    },
    disconnectWallet(state) {
      state.address = null;
      state.provider = null;
      state.connected = false;
      state.chainId = null;
      state.balances = {};
      state.selectedAddress = null;
    },
    setChainId(state, action: PayloadAction<string>) {
      state.chainId = action.payload;
    },
    setBalance(state, action: PayloadAction<{ token: string; balance: string }>) {
      state.balances[action.payload.token] = action.payload.balance;
    },
    clearBalances(state) {
      state.balances = {};
    },
    setSelectedAddress(state, action: PayloadAction<string | null>) {
      state.selectedAddress = action.payload;
    },
  },
});

export const { connectWallet, disconnectWallet, setChainId, setBalance, clearBalances, setSelectedAddress } = walletSlice.actions;
export default walletSlice.reducer;