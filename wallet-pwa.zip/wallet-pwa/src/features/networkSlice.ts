import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface NetworkState {
  chainId: string; // e.g. "0x1", "0x38", etc.
  chainName: string;
  rpcUrl: string;
  explorerUrl: string | null;
  custom: boolean;
}

const initialState: NetworkState = {
  chainId: '0x1',
  chainName: 'Ethereum Mainnet',
  rpcUrl: 'https://mainnet.infura.io/v3/your-project-id',
  explorerUrl: 'https://etherscan.io',
  custom: false,
};

export const networkSlice = createSlice({
  name: 'network',
  initialState,
  reducers: {
    setNetwork(state, action: PayloadAction<{
      chainId: string;
      chainName: string;
      rpcUrl: string;
      explorerUrl?: string;
      custom?: boolean;
    }>) {
      state.chainId = action.payload.chainId;
      state.chainName = action.payload.chainName;
      state.rpcUrl = action.payload.rpcUrl;
      state.explorerUrl = action.payload.explorerUrl ?? null;
      state.custom = !!action.payload.custom;
    },
    addCustomNetwork(state, action: PayloadAction<{
      chainId: string;
      chainName: string;
      rpcUrl: string;
      explorerUrl: string;
    }>) {
      state.chainId = action.payload.chainId;
      state.chainName = action.payload.chainName;
      state.rpcUrl = action.payload.rpcUrl;
      state.explorerUrl = action.payload.explorerUrl;
      state.custom = true;
    },
    removeNetwork(state) {
      // Reset to Ethereum mainnet if custom removed
      state.chainId = '0x1';
      state.chainName = 'Ethereum Mainnet';
      state.rpcUrl = 'https://mainnet.infura.io/v3/your-project-id';
      state.explorerUrl = 'https://etherscan.io';
      state.custom = false;
    },
  },
});

export const { setNetwork, addCustomNetwork, removeNetwork } = networkSlice.actions;
export default networkSlice.reducer;