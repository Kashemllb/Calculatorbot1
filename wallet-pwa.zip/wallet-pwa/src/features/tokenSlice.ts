import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface TokenState {
  customTokens: Record<string, {
    address: string;
    symbol: string;
    decimals: number;
    logo: string; // URL
    name: string;
  }>;
}

const initialState: TokenState = {
  customTokens: {},
};

export const tokenSlice = createSlice({
  name: 'token',
  initialState,
  reducers: {
    addCustomToken(state, action: PayloadAction<{
      address: string;
      symbol: string;
      decimals: number;
      logo: string;
      name: string;
    }>) {
      state.customTokens[action.payload.address.toLowerCase()] = {
        address: action.payload.address,
        symbol: action.payload.symbol,
        decimals: action.payload.decimals,
        logo: action.payload.logo,
        name: action.payload.name,
      };
    },
    removeCustomToken(state, action: PayloadAction<string>) {
      delete state.customTokens[action.payload.toLowerCase()];
    },
    updateCustomToken(state, action: PayloadAction<{
      address: string;
      fields: Partial<{
        symbol: string;
        decimals: number;
        logo: string;
        name: string;
      }>;
    }>) {
      const token = state.customTokens[action.payload.address.toLowerCase()];
      if (token) {
        token.symbol = action.payload.fields.symbol ?? token.symbol;
        token.decimals = action.payload.fields.decimals ?? token.decimals;
        token.logo = action.payload.fields.logo ?? token.logo;
        token.name = action.payload.fields.name ?? token.name;
      }
    },
    clearTokens(state) {
      state.customTokens = {};
    },
  },
});

export const { addCustomToken, removeCustomToken, updateCustomToken, clearTokens } = tokenSlice.actions;
export default tokenSlice.reducer;