import React, { useEffect, useState, createContext, useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { Provider, useSelector, useDispatch } from 'react-redux';
import { useTheme } from './hooks/useTheme';
import { useReducedMotion } from './hooks/useReducedMotion';
import { usePinLock } from './hooks/usePinLock';
import { useSessionTimeout } from './hooks/useSessionTimeout';
import { walletSlice } from './features/walletSlice';
import { networkSlice } from './features/networkSlice';
import { tokenSlice } from './features/tokenSlice';
import { WalletConnect } from './components/WalletConnect';
import { NetworkManager } from './components/NetworkManager';
import { CustomTokenManager } from './components/CustomTokenManager';
import { SwapWidget } from './components/SwapWidget';
import { BalanceDisplay } from './components/BalanceDisplay';
import { ChainsConfig } from './utils/chains';
import { useChains } from './hooks/useChains';
import { NotFound } from './components/NotFound';

const RootContext = createContext<any>(null);

export function App() {
  const dispatch = useDispatch();
  const [isLocked, setIsLocked] = useState(false);
  const { isReducedMotion } = useReducedMotion();
  const { isAuthenticated, requestPin, resetLock } = usePinLock();
  const { timeoutId, startTimeout, clearTimeout: clearTo } = useSessionTimeout(
    () => setIsLocked(true),
    1000 * 60 * 5 // 5 min
  );

  useEffect(() => {
    startTimeout();
    return () => clearTo(timeoutId);
  }, [startTimeout, clearTo]);

  useEffect(() => {
    // Persist unlock state from localStorage if available
    const stored = localStorage.getItem('wallet_unlocked');
    if (stored === '1') {
      setIsLocked(false);
    }
  }, []);

  const toggleLock = () => {
    setIsLocked((prev) => !prev);
    if (!isLocked) {
      localStorage.setItem('wallet_unlocked', '1');
    } else {
      localStorage.removeItem('wallet_unlocked');
      resetLock();
    }
  };

  if (isLocked || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-8 flex items-center justify-center">
        <div className="bg-gray-800 rounded-xl p-6 max-w-md w-full text-center shadow-xl">
          <h2 className="text-2xl font-bold mb-4">Wallet Locked</h2>
          <p className="text-gray-300 mb-6">
            Enter your PIN to unlock the wallet.
          </p>
          <button
            onClick={requestPin}
            className="btn-primary w-full py-3"
          >
            Unlock with PIN
          </button>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 antialiased">
        {/* Theme toggle button */}
        <header className="border-b border-gray-200 flex items-center justify-between px-6 py-4 bg-white shadow-sm">
          <Link to="/" className="text-xl font-semibold">
            <span className="hidden sm:inline">WalletPWA</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path d="M9.5 3.63a2 2 0 1 1 0 3.86L1.8 11.16a2 2 0 1 1-3.4-3.13l5.89-2.78L1.8 4.21a2 2 0 1 1-3.4-3.13L8.9 0a2 2 0 0 1 3.99.56l4.59 2.34L13.5 3.63a2 2 0 0 1 0 3.86l-5.89 2.78L18.2 16.79a2 2 0 1 1-3.4 3.13L10.15 19.6l5.9 3.03a2 2 0 1 1-3.4 3.13L3.9 16.38l5.76-2.88a2 2 0 1 1-3.4-3.13L.9 9.38l5.35-2.55a2 2 0 1 1 0-3.86L9.5 3.63z" />
            </svg>
          </Link>
          <button
            onClick={toggleLock}
            className="hidden sm:block bg-gray-100 rounded-full p-2"
            aria-label="Lock wallet"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                d="M9.063 13.918a.5.5 0 0 1-.373-.837L4.559 9.588a.5.5 0 0 1-.077-.373l4.875-4.875a.5.5 0 0 1-.077.854L9.063 13.918zm-.293-5.707a.5.5 0 0 1 .837-.373l3.452 3.452a.5.5 0 0 1-.373.837l-3.452-3.452a.5.5 0 0 1-.837-.373L9.063 7.5z"
              />
            </svg>
          </button>
        </header>

        <main className="p-4 md:p-6">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/networks" element={<NetworkManager />} />
            <Route path="/tokens" element={<CustomTokenManager />} />
            <Route path="/swap" element={<SwapWidget />} />
            <Route path="/balance" element={<BalanceDisplay />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function Home() {
  const dispatch = useDispatch();
  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <h1 className="text-3xl font-bold mb-6">Multichain Wallet</h1>
      <p className="text-gray-600 mb-8">
        Connect your wallet to manage assets across multiple EVM chains.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <Link to="/networks" className="group bg-white rounded-xl p-6 shadow-hover transition-shadow hover:shadow-lg">
          <h3 className="text-lg font-medium mb-2">Networks</h3>
          <p className="text-gray-500">Add, remove, and snapshot EVM-compatible chains.</p>
        </Link>
        <Link to="/tokens" className="group bg-white rounded-xl p-6 shadow-hover transition-shadow hover:shadow-lg">
          <h3 className="text-lg font-medium mb-2">Tokens</h3>
          <p className="text-gray-500">Add custom ERC‑20 tokens by contract address.</p>
        </Link>
        <Link to="/swap" className="group bg-white rounded-xl p-6 shadow-hover transition-shadow hover:shadow-lg">
          <h3 className="text-lg font-medium mb-2">Swap</h3>
          <p className="text-gray-500">One‑click swaps via 1inch/Paraswap.</p>
        </Link>
      </div>
    </div>
  );
}

export default App;