import { createWeb3Client, ether } from 'wagmi';
import { mainnet, polygon, arbitrum, optimism, bsc,fantom } from 'wagmi/chains';
import { publicProvider } from 'wagmi/providers/public';

// Create wagmi client with multiple chains
const chains = [mainnet, polygon, arbitrum, optimism, bsc, fantom];

export const wagmiClient = createWeb3Client({
  autoConnect: true,
  connectors: [], // connectors will be provided by WC-React
  provider: {
    rpc: (chain) => {
      // Map chain ID to RPC URL; fallback to public RPC
      const rpcMap: Record<number, string> = {
        1: 'https://mainnet.infura.io/v3/',
        137: 'https://polygon-rpc.com',
        42161: 'https://arb1.arbitrum.io/rpc',
        10: 'https://optimism.io/rpc',
        56: 'https://bsc-dataseed.binance.org/',
        250: 'https://rpc.fantom.io',
      };
      const rpc = rpcMap[chain.id] || 'https://cloudflare-eth.com';
      return rpc;
    },
  },
});

// Export a helper to get the provider for use in wagmi hooks
export const provider = wagmiClient.provider;

// Export chain list for UI
export { chains };