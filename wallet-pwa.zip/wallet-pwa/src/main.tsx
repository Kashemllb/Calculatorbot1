import './index.css';
import App from './App';
import { registerSW } from './registerSW';
import { createStore } from '@reduxjs/toolkit';
import { store } from './store';
import { provider } from './web3/provider';
import { walletSlice } from './features/walletSlice';
import { networkSlice } from './features/networkSlice';
import { tokenSlice } from './features/tokenSlice';
import { Provider } from 'react-redux';
import ReactDOM from 'react-dom';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);
registerSW();