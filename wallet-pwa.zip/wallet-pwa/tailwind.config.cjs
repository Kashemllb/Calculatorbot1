/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class', 'selector'],
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [
    require('daisyui'),
  ],
  // optional: https://daisyui.com/docs/optimize-react/
}